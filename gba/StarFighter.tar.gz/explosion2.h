#ifndef EXPLOSION2_BITMAP_H
#define EXPLOSION2_BITMAP_H
extern const unsigned short explosion2[256];
#define EXPLOSION2_WIDTH 16
#define EXPLOSION2_HEIGHT 16
#endif