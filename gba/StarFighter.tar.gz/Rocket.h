#ifndef ROCKET_BITMAP_H
#define ROCKET_BITMAP_H
extern const unsigned short Rocket[45];
#define ROCKET_WIDTH 9
#define ROCKET_HEIGHT 5
#endif