#ifndef BULLET_BITMAP_H
#define BULLET_BITMAP_H
extern const unsigned short Bullet[21];
#define BULLET_WIDTH 7
#define BULLET_HEIGHT 3
#endif