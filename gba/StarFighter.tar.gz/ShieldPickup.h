#ifndef SHIELDPICKUP_BITMAP_H
#define SHIELDPICKUP_BITMAP_H
extern const unsigned short ShieldPickup[144];
#define SHIELDPICKUP_WIDTH 12
#define SHIELDPICKUP_HEIGHT 12
#endif