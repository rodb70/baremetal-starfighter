#ifndef EXPLOSION3_BITMAP_H
#define EXPLOSION3_BITMAP_H
extern const unsigned short explosion3[256];
#define EXPLOSION3_WIDTH 16
#define EXPLOSION3_HEIGHT 16
#endif