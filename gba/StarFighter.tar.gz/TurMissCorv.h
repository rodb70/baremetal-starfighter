#ifndef TURMISSCORV_BITMAP_H
#define TURMISSCORV_BITMAP_H
extern const unsigned short TurMissCorv[450];
#define TURMISSCORV_WIDTH 25
#define TURMISSCORV_HEIGHT 18
#endif