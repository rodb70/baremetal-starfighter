#ifndef TURCORV_BITMAP_H
#define TURCORV_BITMAP_H
extern const unsigned short TurCorv[300];
#define TURCORV_WIDTH 25
#define TURCORV_HEIGHT 12
#endif