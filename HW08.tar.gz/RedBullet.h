#ifndef REDBULLET_BITMAP_H
#define REDBULLET_BITMAP_H
extern const unsigned short RedBullet[21];
#define REDBULLET_WIDTH 7
#define REDBULLET_HEIGHT 3
#endif