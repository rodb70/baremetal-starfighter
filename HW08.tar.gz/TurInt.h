#ifndef TURINT_BITMAP_H
#define TURINT_BITMAP_H
extern const unsigned short TurInt[135];
#define TURINT_WIDTH 15
#define TURINT_HEIGHT 9
#endif