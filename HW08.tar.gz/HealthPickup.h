#ifndef HEALTHPICKUP_BITMAP_H
#define HEALTHPICKUP_BITMAP_H
extern const unsigned short HealthPickup[144];
#define HEALTHPICKUP_WIDTH 12
#define HEALTHPICKUP_HEIGHT 12
#endif