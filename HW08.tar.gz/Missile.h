#ifndef MISSILE_BITMAP_H
#define MISSILE_BITMAP_H
extern const unsigned short Missile[45];
#define MISSILE_WIDTH 9
#define MISSILE_HEIGHT 5
#endif