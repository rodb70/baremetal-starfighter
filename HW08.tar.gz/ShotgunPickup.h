#ifndef SHOTGUNPICKUP_BITMAP_H
#define SHOTGUNPICKUP_BITMAP_H
extern const unsigned short ShotgunPickup[144];
#define SHOTGUNPICKUP_WIDTH 12
#define SHOTGUNPICKUP_HEIGHT 12
#endif