#ifndef KUSINT_BITMAP_H
#define KUSINT_BITMAP_H
extern const unsigned short KusInt[300];
#define KUSINT_WIDTH 20
#define KUSINT_HEIGHT 15
#endif