#ifndef ROCKETPICKUP_BITMAP_H
#define ROCKETPICKUP_BITMAP_H
extern const unsigned short RocketPickup[144];
#define ROCKETPICKUP_WIDTH 12
#define ROCKETPICKUP_HEIGHT 12
#endif